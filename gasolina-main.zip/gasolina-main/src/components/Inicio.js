import Header from '../components/Header'
import Funciones from '../components/Funciones'


export default function Inicio() {
    return (
        <div>
            <Header />
            <Funciones />
        </div>
    )
}